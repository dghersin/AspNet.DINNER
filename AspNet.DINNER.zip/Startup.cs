﻿using $safeprojectname$.Services;

namespace $safeprojectname$
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddScoped<DinnerService>();
            services.AddControllersWithViews();
        }

    }
}
